cari di folder lib trus cari char.js 
disitu tambahkan nomu yg 62xx@s.whatsapp.net 
oh iya fitur RPG char masih tahap pengembangan
kalau ada ide yg bagus tinggal kirim ke ngl ku ada di desk ch

https://whatsapp.com/channel/0029Vb20oaCBFLgcvbsZEs39