import { loadDB, saveDB, OWNER_NUMBERS } from '../lib/char.js'

let handler = async (m, { conn, args }) => {
  if (!OWNER_NUMBERS.includes(m.sender))
    return m.reply('❌ Hanya owner yang bisa memakai command ini.')

  let db = loadDB()
  let id = args[0]
  if (!id) return m.reply('❌ Masukkan ID request.\n\nContoh: .terimappchar abc123')

  let req = db.pendingUbah[id]
  if (!req) return m.reply('❌ ID request tidak ditemukan.')

  db.claimed[req.user].image = req.url
  delete db.pendingUbah[id]
  saveDB(db)

  await m.reply(`✅ Foto karakter @${req.user.split('@')[0]} berhasil diganti.`, null, { mentions: [req.user] })
  await conn.sendMessage(req.user, {
    image: { url: db.claimed[req.user].image },
    caption: `✨ Foto waifu kamu sudah berhasil diganti oleh Owner.`
  })
}

handler.help = ['terimappchar <id>']
handler.tags = ['rpgchar']
handler.command = /^terimappchar$/i

export default handler