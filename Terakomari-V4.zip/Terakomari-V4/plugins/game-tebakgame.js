// tebakgame.js
import fs from 'fs'
import similarity from 'similarity'

let timeout = 120000 // 120 detik
let poin = 4999
const threshold = 0.72 // tingkat kemiripan minimal jawaban

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.game = conn.game ? conn.game : {}
    let id = 'tebakgame-' + m.chat
    if (id in conn.game) {
        return conn.reply(m.chat, '❗ Masih ada soal belum terjawab di chat ini', conn.game[id][0])
    }

    // ambil soal random
    let src = JSON.parse(fs.readFileSync('./json/tebakgame.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]

    let caption = `
🖼️ Logo apakah ini?

⏳ Timeout: *${(timeout / 1000).toFixed(0)} detik*
💡 Ketik *${usedPrefix}hgame* untuk bantuan
🎁 Bonus: *${poin} XP*
`.trim()

    conn.game[id] = [
        await conn.sendFile(m.chat, json.img, 'tebakgame.jpg', caption, m),
        json, poin,
        setTimeout(() => {
            if (conn.game[id]) {
                conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.game[id][0])
                delete conn.game[id]
            }
        }, timeout)
    ]
}
handler.help = ['tebakgame']
handler.tags = ['game']
handler.command = /^tebakgame$/i
handler.onlyprem = true
handler.game = true

// handler untuk ngecek jawaban
handler.before = async (m, { conn }) => {
    conn.game = conn.game ? conn.game : {}
    let id = 'tebakgame-' + m.chat
    if (!(id in conn.game)) return false

    let [msg, json, poin, timeoutId] = conn.game[id]
    let jawaban = json.jawaban.toLowerCase()
    let userAns = m.text.toLowerCase().trim()

    if (userAns === jawaban || similarity(userAns, jawaban) >= threshold) {
        conn.reply(m.chat, `✅ Benar!\nJawabannya adalah *${json.jawaban}*\n🎉 Kamu dapat *${poin} XP*`, m)
        clearTimeout(timeoutId)
        delete conn.game[id]
        return true
    } else {
        // kalau mau kasih clue atau feedback salah
        // bisa dihapus kalau tidak mau spam
        // m.reply('❌ Jawaban salah, coba lagi!')
    }
    return true
}

export default handler