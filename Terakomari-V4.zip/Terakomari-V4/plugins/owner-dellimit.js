let handler = async (m, { conn, command, text, args }) => {
    if (!text) throw `⚠️ Contoh: .${command} @tag 50\natau: .${command} 6281234567890 100`

    let who
    let jumlah = isNaN(args[1]) ? (parseInt(args[0]) ? parseInt(args[0]) : 0) : parseInt(args[1])

    // cari target user
    if (m.isGroup) {
        // kalau pakai tag
        if (m.mentionedJid[0]) {
            who = m.mentionedJid[0]
        } 
        // kalau pakai nomor manual
        else if (args[0] && !isNaN(args[0])) {
            who = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        }
    } else {
        who = m.chat
    }

    if (!who) throw `⚠️ Harap tag atau masukkan nomor user!`
    if (!jumlah || jumlah <= 0) throw `⚠️ Masukkan jumlah limit yang benar!`

    let users = global.db.data.users
    if (!users[who]) throw `❌ User tidak ada di database.`

    // Kurangi limit, minimal 0
    users[who].limit = Math.max(0, users[who].limit - jumlah)

    conn.reply(m.chat, `✅ Limit berhasil dikurangi\n\n👤 User: @${who.split('@')[0]}\n➖ Jumlah: *${jumlah}*\n📉 Sisa: *${users[who].limit}*`, m, {
        mentions: [who]
    })
}

handler.help = ['dellimit']
handler.tags = ['owner']
handler.command = /^dellimit$/i
handler.rowner = true

export default handler