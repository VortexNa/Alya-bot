import { loadDB, saveDB } from '../lib/char.js'

let handler = async (m, { conn }) => {
  let db = loadDB()
  const req = global.waifuRequest?.[m.sender]
  if (!req) return m.reply('❌ Tidak ada karakter yang sedang diajukan.')
  if (db.claimed[m.sender]) 
    return m.reply('❌ Kamu sudah punya karakter, putus dulu sebelum klaim lagi.')

  const chara = req.chara
  let sudahAda = Object.entries(db.claimed).find(([jid, data]) => data.nama === chara.nama)
  if (sudahAda) {
    let ownerJid = String(sudahAda[0]) 
    return conn.sendMessage(
      m.chat,
      { 
        text: `❌ karakter *${chara.nama}* sudah dimiliki oleh @${ownerJid.split('@')[0]}`, 
        mentions: [ownerJid] 
      },
      { quoted: m }
    )
  }
  db.claimed[m.sender] = { 
    nama: chara.nama, 
    image: chara.image, 
    point: 0, 
    claimDate: Date.now(), 
    lastInteraksi: 0 
  }
  saveDB(db)
  delete global.waifuRequest[m.sender]

  return conn.sendMessage(
    m.chat, 
    { 
      image: { url: chara.image }, 
      caption: `💖 Selamat! Kamu resmi jadian dengan *${chara.nama}*` 
    }, 
    { quoted: m }
  )
}

handler.help = ['terimachar']
handler.tags = ['rpgchar']
handler.command = /^terimachar$/i

export default handler