import { loadDB, saveDB, uploadCloudku, convertToGif, OWNER_NUMBERS } from '../lib/char.js'
import fs from 'fs'
import path from 'path'
import { tmpdir } from 'os'

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted || m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) return m.reply(`❌ Reply gambar/video untuk setppchar.\n\nContoh: ${usedPrefix}${command}`)

  let db = loadDB()
  let user = db.claimed[m.sender]
  if (!user) return m.reply('❌ Kamu belum punya waifu.')

  let media = await q.download()
  if (!media) return m.reply('❌ Gagal download media.')

  let filePath = path.join(tmpdir(), Date.now() + '.' + mime.split('/')[1])
  fs.writeFileSync(filePath, media)

  let finalPath = filePath
  if (mime.startsWith('video')) {
    finalPath = filePath.replace(/\.\w+$/, '.gif')
    let gif = await convertToGif(filePath, finalPath)
    if (!gif) return m.reply('❌ Gagal convert video ke gif.')
  }

  let url = await uploadCloudku(finalPath)
  if (!url) return m.reply('❌ Gagal upload ke cloud.')

  // Buat ID unik untuk request
  let id = Date.now().toString(36) // contoh: "l7c4x2q"
  db.pendingUbah[id] = { url, old: user.image, user: m.sender }
  saveDB(db)

  // Info ke user
  await m.reply(`✅ Foto baru sudah dikirim ke *Owner* untuk direview.\nTunggu konfirmasi.`)

  // Info ke semua owner
  for (let owner of OWNER_NUMBERS) {
    await conn.sendMessage(owner, {
      image: { url },
      caption: `📌 Request ubah foto waifu dari @${m.sender.split('@')[0]}\n🆔 ID: *${id}*\n\nGunakan *.terimappchar ${id}* untuk menerima atau *.tolakppchar ${id}* untuk menolak.`,
      mentions: [m.sender]
    })
  }
}

handler.help = ['setppchar', 'ubahppchar']
handler.tags = ['rpgchar']
handler.command = /^setppchar|ubahppchar$/i

export default handler