let handler = async (m) => {
  m.reply(`
*╭─────『 Menu RPG Char 』
ᯓ .char
ᯓ .terimachar
ᯓ .putus
ᯓ .interaksi 
ᯓ .profilchar
ᯓ .setppchar
ᯓ .accppchar
ᯓ .terimappchar
ᯓ .tolakppchar
ᯓ .topwaifu
╰–––––––––––––––༓
`.trim())
}
handler.command = /^menurpgchar$/i
handler.help = ["menurpgchar"]
handler.tags = ["main"]
export default handler