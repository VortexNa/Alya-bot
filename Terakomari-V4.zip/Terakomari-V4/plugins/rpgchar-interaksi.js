import { loadDB, saveDB } from '../lib/char.js'

let handler = async (m, { conn }) => {
  let db = loadDB()
  let user = db.claimed[m.sender]
  if (!user) return m.reply('❌ Kamu belum punya waifu.')

  let now = Date.now()
  if (now - user.lastInteraksi < 2 * 60 * 1000) {
    let sisa = Math.ceil((2 * 60 * 1000 - (now - user.lastInteraksi)) / 1000)
    return m.reply(`⏳ Tunggu ${sisa} detik sebelum interaksi lagi.`)
  }

  const actions = [
    `jalan-jalan romantis dengan ${user.nama}`,
    `makan malam bersama ${user.nama}`,
    `belajar bareng ${user.nama}`,
    `nonton film sama ${user.nama}`,
    `bercanda manis dengan ${user.nama}`
  ]
  const action = actions[Math.floor(Math.random() * actions.length)]
  const pointGain = Math.floor(Math.random() * 31) + 20

  user.point += pointGain
  user.lastInteraksi = now
  db.claimed[m.sender] = user
  saveDB(db)

  return m.reply(
    `✨ Kamu ${action}\n+${pointGain} Point Interaksi\nTotal: ${user.point} point`
  )
}

handler.help = ['interaksi']
handler.tags = ['rpgchar']
handler.command = /^interaksi$/i

export default handler