let handler = async (m, { conn, text, usedPrefix, command }) => {
  const categories = ['level', 'limit', 'exp']

  if (!text || !categories.includes(text.toLowerCase())) {
    return m.reply(
`📊 *LEADERBOARD*

Silakan pilih kategori:
- Ketik: *${usedPrefix}${command} level*
- Ketik: *${usedPrefix}${command} limit*
- Ketik: *${usedPrefix}${command} exp*`
    )
  }

  let users = Object.entries(global.db.data.users).map(([jid, data]) => ({
    jid,
    name: data.name || jid.split('@')[0],
    level: data.level || 0,
    limit: data.limit || 0,
    exp: data.exp || 0,
    phone: jid.replace(/@.+/, '')
  }))

  if (!users.length) return m.reply('❌ Belum ada data user.')

  let title = ''
  let list = []

  switch (text.toLowerCase()) {
    case 'level':
      users.sort((a, b) => b.level - a.level)
      title = '🏆 LEADERBOARD LEVEL'
      list = users.map((u, i) => {
        let medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`
        return `${medal} | ${u.name} [${u.phone}]\n   Level: ${u.level}`
      })
      break
    case 'limit':
      users.sort((a, b) => b.limit - a.limit)
      title = '🏆 LEADERBOARD LIMIT'
      list = users.map((u, i) => {
        let medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`
        return `${medal} | ${u.name} [${u.phone}]\n   Limit: ${u.limit}`
      })
      break
    case 'exp':
      users.sort((a, b) => b.exp - a.exp)
      title = '🏆 LEADERBOARD EXP'
      list = users.map((u, i) => {
        let medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`
        return `${medal} | ${u.name} [${u.phone}]\n   XP: ${u.exp}`
      })
      break
  }

  // Ambil 10 besar (tanpa simbol ║)
  const top = list.slice(0, 10).join('\n\n')

  const yourIndex = users.findIndex(u => u.jid === m.sender)

  const yourRank = yourIndex !== -1
    ? `\n📌 Posisi kamu: *#${yourIndex + 1}* [${users[yourIndex].phone}]`
    : ''

  const totalUsers = `\n👥 Total User Terdaftar: *${users.length}*`

  const result = `〘 ${title} 〙

${top}

${yourRank}${totalUsers}`

  m.reply(result)
}

handler.help = ['leaderboard <level|limit|exp>']
handler.tags = ['game']
handler.command = /^leaderboard$/i

export default handler