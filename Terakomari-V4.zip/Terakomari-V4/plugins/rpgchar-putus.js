import { loadDB, saveDB } from '../lib/char.js'

let handler = async (m) => {
  let db = loadDB()
  if (!db.claimed[m.sender]) return m.reply('❌ Kamu tidak punya waifu.')
  
  let waifu = db.claimed[m.sender].nama
  delete db.claimed[m.sender]
  saveDB(db)

  return m.reply(`💔 Kamu sudah putus dengan *${waifu}*.`)
}

handler.help = ['putus']
handler.tags = ['rpgchar']
handler.command = /^putus$/i

export default handler