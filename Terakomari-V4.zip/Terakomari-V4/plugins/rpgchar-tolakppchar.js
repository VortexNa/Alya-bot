import { loadDB, saveDB, OWNER_NUMBERS } from '../lib/char.js'

let handler = async (m, { conn, args }) => {
  if (!OWNER_NUMBERS.includes(m.sender))
    return m.reply('❌ Hanya owner yang bisa memakai command ini.')

  let db = loadDB()
  let id = args[0]
  if (!id) return m.reply('❌ Masukkan ID request.\n\nContoh: .tolakppchar abc123')

  let req = db.pendingUbah[id]
  if (!req) return m.reply('❌ ID request tidak ditemukan.')

  delete db.pendingUbah[id]
  saveDB(db)

  // Info ke owner
  await m.reply(`❌ Request ubah foto waifu @${req.user.split('@')[0]} ditolak.`, null, { mentions: [req.user] })

  // Info ke user (privat chat)
  await conn.sendMessage(req.user, {
    text: `❌ Maaf, request ubah foto waifu kamu ditolak oleh Owner.`
  })
}

handler.help = ['tolakppchar <id>']
handler.tags = ['rpgchar']
handler.command = /^tolakppchar$/i

export default handler