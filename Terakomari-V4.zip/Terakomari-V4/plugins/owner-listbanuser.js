let handler = async (m, { conn }) => {
    let users = global.db.data.users
    let bannedUsers = Object.keys(users).filter(jid => users[jid].banned)

    if (bannedUsers.length === 0) {
        return m.reply('✅ Tidak ada user yang sedang dibanned.')
    }

    let list = bannedUsers.map((jid, i) => {
        let u = users[jid]
        let reason = u.banReason || 'Tidak ada alasan'
        let expires = u.banExpires
            ? `⏰ Habis: ${new Date(u.banExpires).toLocaleString()}`
            : '⏰ Permanen'
        return `*${i + 1}.* @${jid.split('@')[0]}\n📄 Alasan: ${reason}\n${expires}`
    }).join('\n\n')

    conn.reply(m.chat, `📋 *Daftar User yang dibanned:*\n\n${list}`, m, {
        mentions: bannedUsers
    })
}

handler.help = ['listban']
handler.tags = ['owner']
handler.command = /^listban$/i
handler.rowner = true

export default handler