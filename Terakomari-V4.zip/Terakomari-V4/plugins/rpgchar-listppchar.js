import { loadDB, OWNER_NUMBERS } from '../lib/char.js'

let handler = async (m, { conn }) => {
  if (!OWNER_NUMBERS.includes(m.sender))
    return m.reply('❌ Hanya owner yang bisa memakai command ini.')

  let db = loadDB()
  let list = Object.entries(db.pendingUbah)

  if (!list.length) return m.reply('❌ Tidak ada request ubah ppchar.')

  let teks = `📋 *Daftar Request Ubah Foto Character*\n\n`
  for (let [id, data] of list) {
    teks += `🆔 ID: *${id}*\n👤 @${data.user.split('@')[0]}\n🔗 ${data.url}\n\n`
  }

  return conn.sendMessage(m.chat, { text: teks, mentions: list.map(([_, d]) => d.user) })
}

handler.help = ['listppchar']
handler.tags = ['rpgchar']
handler.command = /^listppchar$/i

export default handler