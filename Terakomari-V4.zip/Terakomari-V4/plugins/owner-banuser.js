let handler = async (m, { conn, text, args }) => {
    if (!text) throw `❌ Siapa yang mau di-ban?\n\nContoh:\n.ban @user 10m spam\n.ban 6281234567890 1h toxic`

    let who
    let time = 'permanent'
    let reason = 'No reason'

    // Kalau ada tag
    if (m.mentionedJid.length > 0) {
        who = m.mentionedJid[0]
    } else {
        // Kalau pakai nomor
        let phoneNumber = args[0]?.replace(/[^0-9]/g, '')
        if (!phoneNumber) throw '❌ Masukkan @tag atau nomor user.'
        who = phoneNumber + '@s.whatsapp.net'
    }

    // Ambil durasi ban (opsional)
    let durationInput = args[1]
    let durationMs = 0
    if (durationInput) {
        let match = durationInput.match(/(\d+)([smhd])/i) // contoh: 10m, 2h, 1d
        if (match) {
            let value = parseInt(match[1])
            let unit = match[2].toLowerCase()
            if (unit === 's') durationMs = value * 1000
            if (unit === 'm') durationMs = value * 60 * 1000
            if (unit === 'h') durationMs = value * 60 * 60 * 1000
            if (unit === 'd') durationMs = value * 24 * 60 * 60 * 1000
            time = durationInput
        } else {
            reason = args.slice(1).join(' ')
        }
    }

    // Ambil reason (jika ada setelah durasi)
    if (durationMs > 0) {
        reason = args.slice(2).join(' ') || reason
    } else {
        reason = args.slice(1).join(' ') || reason
    }

    let users = global.db.data.users
    if (!users[who]) users[who] = {}

    users[who].banned = true
    users[who].banReason = reason
    users[who].banExpires = durationMs > 0 ? (Date.now() + durationMs) : null

    conn.reply(m.chat, `🚫 User diban ${time === 'permanent' ? 'PERMANEN' : `selama ${time}`}\n\n👤 User: @${who.split('@')[0]}\n📄 Alasan: ${reason}`, m, {
        mentions: [who]
    })
}

handler.help = ['ban @tag/nomor [durasi] [alasan]']
handler.tags = ['owner']
handler.command = /^ban(user)?$/i
handler.rowner = true

export default handler
