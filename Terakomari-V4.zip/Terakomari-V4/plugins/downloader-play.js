import fetch from 'node-fetch'
 
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh: ${usedPrefix + command} tarot feast`
 
  try {
    let res = await fetch(`https://api.nekolabs.my.id/downloader/youtube/play/v1?q=${encodeURIComponent(text)}`)
    if (!res.ok) throw await res.text()
    let json = await res.json()
 
    if (!json.status) throw `❌ Lagu tidak ditemukan.`
 
    let { metadata, downloadUrl } = json.result
    let { title, channel, duration, cover, url } = metadata
 
    let caption = `🎵 *${title}*
👤 Channel: ${channel}
⏱️ Durasi: ${duration}
🔗 ${url}`
 
    await conn.sendMessage(m.chat, {
      image: { url: cover },
      caption
    }, { quoted: m })
 
    await conn.sendMessage(m.chat, {
      audio: { url: downloadUrl },
      mimetype: 'audio/mp4',
      fileName: `${title}.mp3`
    }, { quoted: m })
 
  } catch (e) {
    throw `❌ Terjadi kesalahan!\n\n${e}`
  }
}
 
handler.help = ['play <judul>']
handler.tags = ['downloader']
handler.command = /^play$/i
handler.limit = true
 
export default handler