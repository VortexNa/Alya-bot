import { loadDB } from '../lib/char.js'

let handler = async (m) => {
  let db = loadDB()
  let list = Object.entries(db.claimed)
    .map(([jid, data]) => ({ jid, ...data }))
    .sort((a, b) => b.point - a.point)

  if (!list.length) return m.reply('❌ Belum ada waifu yang diklaim.')

  let teks = `🏆 *Top Waifu Leaderboard*\n\n`
  list.forEach((u, i) => {
    teks += `${i + 1}. @${u.jid.split('@')[0]} ❤️ ${u.point} - *${u.nama}*\n`
  })

  return m.reply(teks, null, { mentions: list.map(u => u.jid) })
}

handler.help = ['topwaifu']
handler.tags = ['rpgchar']
handler.command = /^topwaifu$/i

export default handler