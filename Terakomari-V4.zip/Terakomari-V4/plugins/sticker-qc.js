import { sticker } from '../lib/sticker.js'
import axios from 'axios'

const handler = async (m, { conn, args }) => {
    let text

    if (args.length >= 1) {
        text = args.join(" ")
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text
    } else throw "❌ Mana teksnya?"

    if (!text) return m.reply('❌ Mana teksnya?')
    let who
    if (m.quoted) {
        who = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid[0]) {
        who = m.mentionedJid[0]
    } else {
        who = m.sender
    }

    const pp = await conn.profilePictureUrl(who).catch(_ => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')

    let name = (conn.chats[who]?.name) || (m.quoted?.pushName) || (m.pushName) || who.split('@')[0]

    const obj = {
        type: "quote",
        format: "png",
        backgroundColor: "#FFFFFF",
        width: 1024,
        height: 1024,
        scale: 2,
        messages: [{
            entities: [],
            avatar: true,
            from: {
                id: 1,
                name: name,
                photo: { url: pp }
            },
            text: text
        }]
    }

    const json = await axios.post('https://qc.botcahx.eu.org/generate', obj, {
        headers: { 'Content-Type': 'application/json' }
    })

    const buffer = Buffer.from(json.data.result.image, 'base64')
    let stiker = await sticker(buffer, false, global.stickpack, global.stickauth)
    if (stiker) return conn.sendFile(m.chat, stiker, 'qc.webp', '', m)
}

handler.help = ['qc']
handler.tags = ['sticker']
handler.command = /^qc$/i
handler.limit = true
handler.register = true

export default handler