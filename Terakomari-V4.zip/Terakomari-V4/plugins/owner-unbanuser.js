let handler = async (m, { conn, text, args }) => {
    if (!text) throw `❌ Siapa yang mau di-unban?\n\nContoh:\n.unban @user\n.unban 6281234567890`

    let who

    // Kalau ada tag
    if (m.mentionedJid.length > 0) {
        who = m.mentionedJid[0]
    } else {
        // Kalau pakai nomor
        let phoneNumber = args[0]?.replace(/[^0-9]/g, '')
        if (!phoneNumber) throw '❌ Masukkan @tag atau nomor user.'
        who = phoneNumber + '@s.whatsapp.net'
    }

    let users = global.db.data.users
    if (!users[who]) users[who] = {}

    if (!users[who].banned) {
        return conn.reply(m.chat, `⚠️ User @${who.split('@')[0]} tidak sedang dibanned.`, m, {
            mentions: [who]
        })
    }

    users[who].banned = false
    users[who].banReason = ''
    users[who].banExpires = null

    conn.reply(m.chat, `✅ User @${who.split('@')[0]} berhasil di-UNBAN.`, m, {
        mentions: [who]
    })
}

handler.help = ['unban @tag/nomor']
handler.tags = ['owner']
handler.command = /^unban(user)?$/i
handler.rowner = true

export default handler
