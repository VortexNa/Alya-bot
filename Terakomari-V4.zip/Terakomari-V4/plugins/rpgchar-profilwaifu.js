import { loadDB } from '../lib/char.js'

let handler = async (m, { conn }) => {
  let db = loadDB()
  let user = db.claimed[m.sender]
  if (!user) return m.reply('❌ Kamu belum punya waifu.')

  return conn.sendMessage(
    m.chat,
    {
      image: { url: user.image },
      caption: `💌 *Profil Waifu*\n\n🌸 Nama: *${user.nama}*\n❤️ Poin: *${user.point}*\n📅 Claim: *${new Date(user.claimDate).toLocaleString()}*`
    },
    { quoted: m }
  )
}

handler.help = ['profilwaifu']
handler.tags = ['rpgchar']
handler.command = /^profilwaifu$/i

export default handler