import { searchMALCharacter } from '../lib/char.js'

let handler = async (m, { conn, command, text, usedPrefix }) => {
  global.waifuRequest = global.waifuRequest || {}
  if (!text) {
    return m.reply(
      `❌ Format salah.\n\n${usedPrefix}char nama_karakter\n${usedPrefix}char ID_karakter`
    )
  }

  const chara = await searchMALCharacter(text)
  if (!chara) return m.reply('❌ Karakter tidak ditemukan di MyAnimeList.')

  global.waifuRequest[m.sender] = { chara, time: Date.now() }
  setTimeout(() => {
    if (global.waifuRequest?.[m.sender]) delete global.waifuRequest[m.sender]
  }, 2 * 60 * 1000)

  return conn.sendMessage(
    m.chat,
    {
      image: { url: chara.image },
      caption: `🎀 *Karakter Ditemukan!*\n\n🌸 Nama: *${chara.nama}*\n🆔 ID MAL: *${chara.id}*\n\n👉 Gunakan:\n• *.terimachar* untuk klaim\n• *.tolakchar* untuk batal\n\n⚠️ Request ini hanya berlaku 2 menit.`
    },
    { quoted: m }
  )
}

handler.help = ['char <nama/id>']
handler.tags = ['rpgchar']
handler.command = /^char$/i

export default handler