/*
* Nama fitur : To figure
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb20oaCBFLgcvbsZEs39
* Author : Allen
* Scrape By : Gienetic : https://whatsapp.com/channel/0029Vb5EZCjIiRotHCI1213L/448
*/

import axios from 'axios'
import FormData from 'form-data'
import crypto from 'crypto'

const BASE_URL = 'https://ai-apps.codergautam.dev'
const PROMPT = 'a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment. The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base. The computer screen shows the Zbrush modeling process of the figurine. Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.'

function acakName(len = 10) {
  const chars = 'abcdefghijklmnopqrstuvwxyz'
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
}

async function autoregist() {
  const uid = crypto.randomBytes(12).toString('hex')
  const email = `gienetic${Date.now()}@gmail.com`

  const payload = {
    uid,
    email,
    displayName: acakName(),
    photoURL: 'https://i.pravatar.cc/150',
    appId: 'photogpt'
  }

  const res = await axios.post(`${BASE_URL}/photogpt/create-user`, payload, {
    headers: {
      'content-type': 'application/json',
      'accept': 'application/json',
      'user-agent': 'okhttp/4.9.2'
    }
  })

  if (res.data.success) return uid
  throw new Error('Register gagal cuy: ' + JSON.stringify(res.data))
}

async function img2img(imageBuffer, prompt, pollInterval = 3000, pollTimeout = 2 * 60 * 1000) {
  const uid = await autoregist()

  const form = new FormData()
  form.append('image', imageBuffer, { filename: 'input.jpg', contentType: 'image/jpeg' })
  form.append('prompt', prompt)
  form.append('userId', uid)

  const uploadRes = await axios.post(`${BASE_URL}/photogpt/generate-image`, form, {
    headers: {
      ...form.getHeaders(),
      'accept': 'application/json',
      'user-agent': 'okhttp/4.9.2',
      'accept-encoding': 'gzip'
    },
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
    timeout: 120000
  })

  if (!uploadRes.data.success) throw new Error(JSON.stringify(uploadRes.data))

  const pollingUrl = uploadRes.data.pollingUrl || (uploadRes.data.jobId ? `${BASE_URL}/photogpt/job/${uploadRes.data.jobId}` : null)
  if (!pollingUrl) throw new Error('Polling URL tidak ditemukan.')

  let status = 'pending'
  let resultUrl = null
  const startTime = Date.now()

  while (true) {
    if (Date.now() - startTime > pollTimeout) throw new Error('Polling timeout.')

    const pollRes = await axios.get(pollingUrl, {
      headers: {
        'accept': 'application/json',
        'user-agent': 'okhttp/4.9.2',
        'accept-encoding': 'gzip'
      }
    })

    status = (pollRes.data.status || '').toLowerCase()
    if (['ready', 'complete', 'success'].includes(status)) {
      resultUrl = pollRes.data.result?.url || pollRes.data.url || (Array.isArray(pollRes.data.result) ? pollRes.data.result[0]?.url : null)
      if (!resultUrl) throw new Error('Job selesai tapi URL gambar tidak ditemukan.')
      break
    }

    await new Promise(r => setTimeout(r, pollInterval))
  }

  const resultImg = await axios.get(resultUrl, { responseType: 'arraybuffer', headers: { 'accept-encoding': 'gzip' } })
  return Buffer.from(resultImg.data)
}

function autoDelete(conn, chat, msg, ms = 30000) {
  setTimeout(() => {
    conn.sendMessage(chat, { delete: msg.key }).catch(() => {})
  }, ms)
}

const handler = async (m, { conn, args }) => {
  try {
    let imageBuffer

    if (args[0] && args[0].startsWith('http')) {
      const resp = await axios.get(args[0], { responseType: 'arraybuffer' })
      imageBuffer = Buffer.from(resp.data)
    } else if (m.quoted) {
      const mime = m.quoted.mimetype || ''
      if (!/image/.test(mime)) {
        return m.reply('❌ Yang direply harus berupa gambar atau kasih URL gambar')
      }
      imageBuffer = await m.quoted.download?.()
    }

    if (!imageBuffer) {
      return m.reply('❌ Harus reply ke gambar atau kasih URL gambar.\n\nContoh:\n.tofigure (reply gambar)\n.tofigure https://example.com/image.jpg')
    }

    const loadingMsg = await m.reply('⏳ Lagi diproses, sabar ya...')
    autoDelete(conn, m.chat, loadingMsg)

    const hasil = await img2img(imageBuffer, PROMPT)

    await conn.sendMessage(
      m.chat,
      { image: hasil, caption: '✅ Jadi nih figurenya!' },
      { quoted: m }
    )

  } catch (e) {
    return m.reply(`❌ Error: ${e.message}`)
  }
}

handler.help = ['tofigure']
handler.tags = ['maker']
handler.command = /^tofigure$/i

export default handler