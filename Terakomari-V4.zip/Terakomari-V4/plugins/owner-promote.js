import { areJidsSameUser } from '@adiwajshing/baileys'

let handler = async (m, { conn, args, participants }) => {
    let mentioned = m.mentionedJid || []
    let textArgs = args || []

    // Gabungkan dari tag dan nomor
    let targets = new Set()

    // Dari tag
    for (let jid of mentioned) {
        if (!areJidsSameUser(jid, conn.user.jid)) {
            targets.add(jid)
        }
    }

    // Dari nomor
    for (let txt of textArgs) {
        let number = txt.replace(/[^0-9]/g, '') // Hapus simbol
        if (number.length > 5) {
            let jid = number + '@s.whatsapp.net'
            if (!areJidsSameUser(jid, conn.user.jid)) {
                targets.add(jid)
            }
        }
    }

    if (targets.size === 0) return m.reply('Tag atau ketik nomor yang ingin dipromosikan.')

    // Cek apakah bot admin
    let bot = participants.find(p => areJidsSameUser(p.id, conn.user.jid))
    if (!bot?.admin) return m.reply('Bot harus menjadi admin untuk mempromosikan anggota.')

    let promoteSuccess = []
    let promoteFail = []

    for (let user of targets) {
        let participant = participants.find(p => areJidsSameUser(p.id, user))

        if (
            user.endsWith('@s.whatsapp.net') &&
            participant &&
            participant.admin !== 'admin' &&
            participant.admin !== 'superadmin'
        ) {
            try {
                await conn.groupParticipantsUpdate(m.chat, [user], 'promote')
                promoteSuccess.push(user)
                await delay(1000)
            } catch (e) {
                console.error(`Gagal promote ${user}:`, e)
                promoteFail.push(user)
            }
        } else {
            promoteFail.push(user)
        }
    }

    // Balas hasil
    let teks = ''
    if (promoteSuccess.length > 0) {
        teks += `✅ Berhasil mempromosikan:\n${promoteSuccess.map(u => '• @' + u.split('@')[0]).join('\n')}\n`
    }
    if (promoteFail.length > 0) {
        teks += `\n❌ Gagal mempromosikan:\n${promoteFail.map(u => '• @' + u.split('@')[0]).join('\n')}`
    }

    m.reply(teks.trim(), null, { mentions: [...promoteSuccess, ...promoteFail] })
}

handler.help = ['opromote @tag / nomor']
handler.tags = ['owner']
handler.command = /^(opromote)$/i

handler.owner = true
handler.group = true
handler.botAdmin = true

export default handler

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))