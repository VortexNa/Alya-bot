import makeWASocket, { useMultiFileAuthState, delay as baileysDelay } from '@whiskeysockets/baileys'
import { conversation } from './conversation.js'

const nomorA = "6282121286563@s.whatsapp.net" // nomor BotA
let currentIndex = 0
const delay = ms => new Promise(res => setTimeout(res, ms))

async function startBotB() {
  const { state, saveCreds } = await useMultiFileAuthState('./botB/session')
  const sock = makeWASocket({ auth: state })
  sock.ev.on('creds.update', saveCreds)
  console.log("✅ BotB siap.")

  // Fungsi kirim pesan dari BotB
  async function sendNext() {
    if (currentIndex >= conversation.length) return
    const line = conversation[currentIndex]
    if (line.from !== "B") return

    await sock.sendMessage(nomorA, { text: line.text })
    console.log(`BotB → ${line.text}`)

    currentIndex++
  }

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0]
    if (!m.message) return
    if (m.key.fromMe) return
    if (m.key.remoteJid !== nomorA) return

    const pesan = m.message.conversation || m.message.extendedTextMessage?.text
    console.log(`Pesan masuk dari BotA: ${pesan}`)

    // Hindari pengiriman ganda
    const nextLine = conversation[currentIndex]
    if (!nextLine) return

    if (nextLine.from === "B") {
      await sendNext()
    } else {
      // Lompat ke baris berikutnya sampai ketemu dialog dari BotB
      while (currentIndex < conversation.length) {
        currentIndex++
        if (conversation[currentIndex]?.from === "B") {
          await sendNext()
          break
        }
      }
    }
  })
}

startBotB()
