const { makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys')
const qrcode = require('qrcode-terminal')

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('./session')

  const sock = makeWASocket({
    auth: state,
    // jangan pakai printQRInTerminal, sudah deprecated
    browser: ['Ubuntu', 'Chrome', '22.04.4']
  })

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', (update) => {
    const { qr, connection } = update

    if (qr) {
      console.clear()
      console.log('📱 Scan QR berikut dengan WhatsApp kamu:')
      qrcode.generate(qr, { small: true })
    }

    if (connection === 'open') {
      console.log('✅ Login berhasil! Session tersimpan di ./session/')
    }
  })
}

start()
