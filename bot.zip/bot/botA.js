import makeWASocket, { useMultiFileAuthState } from '@whiskeysockets/baileys'  
import { conversation } from './conversation.js'  
  
const nomorB = "6283842463427@s.whatsapp.net" // nomor BotB  
let currentIndex = 0  
const delay = ms => new Promise(res => setTimeout(res, ms))  
  
async function startBotA() {  
  const { state, saveCreds } = await useMultiFileAuthState('./botA/session')  
  const sock = makeWASocket({ auth: state })  
  sock.ev.on('creds.update', saveCreds)  
  console.log("✅ BotA siap.")  
  
  // Fungsi kirim pesan dari BotA  
  async function sendNext() {  
    if (currentIndex >= conversation.length) return  
    const line = conversation[currentIndex]  
    if (line.from !== "A") return  
    await delay(Math.floor(Math.random() * 4000) + 2000)  
    await sock.sendMessage(nomorB, { text: line.text })  
    console.log(`BotA → ${line.text}`)  
    currentIndex++  
  }  
  
  // Deteksi pesan masuk dari BotB  
  sock.ev.on('messages.upsert', async ({ messages }) => {  
    const m = messages[0]  
    if (!m.message) return  
    if (m.key.fromMe) return // abaikan pesan dari BotA sendiri  
    if (m.key.remoteJid !== nomorB) return  
  
    const pesan = m.message.conversation || m.message.extendedTextMessage?.text  
    console.log(`Pesan masuk dari BotB: ${pesan}`)  
  
    const line = conversation[currentIndex]  
  
    // Jika giliran BotA membalas  
    if (line && line.from === "A") {  
      await sendNext()  
    } else {  
      // Lompat ke baris berikutnya sampai ketemu giliran A  
      while (currentIndex < conversation.length) {  
        currentIndex++  
        if (conversation[currentIndex]?.from === "A") {  
          await sendNext()  
          break  
        }  
      }  
    }  
  })  
  
  // Kirim pesan pembuka (kalau giliran pertama A)  
  if (conversation[0].from === "A") {  
    await sendNext()  
  }  
}  
  
startBotA()
